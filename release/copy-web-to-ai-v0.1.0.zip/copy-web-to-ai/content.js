function Ae(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e}function I(e,t){return Array(t+1).join(e)}function ae(e){return e.replace(/^\n*/,"")}function ie(e){for(var t=e.length;t>0&&e[t-1]===`
`;)t--;return e.substring(0,t)}function oe(e){return ie(ae(e))}var Ne=["ADDRESS","ARTICLE","ASIDE","AUDIO","BLOCKQUOTE","BODY","CANVAS","CENTER","DD","DIR","DIV","DL","DT","FIELDSET","FIGCAPTION","FIGURE","FOOTER","FORM","FRAMESET","H1","H2","H3","H4","H5","H6","HEADER","HGROUP","HR","HTML","ISINDEX","LI","MAIN","MENU","NAV","NOFRAMES","NOSCRIPT","OL","OUTPUT","P","PRE","SECTION","TABLE","TBODY","TD","TFOOT","TH","THEAD","TR","UL"];function U(e){return F(e,Ne)}var le=["AREA","BASE","BR","COL","COMMAND","EMBED","HR","IMG","INPUT","KEYGEN","LINK","META","PARAM","SOURCE","TRACK","WBR"];function se(e){return F(e,le)}function Se(e){return ue(e,le)}var ce=["A","TABLE","THEAD","TBODY","TFOOT","TH","TD","IFRAME","SCRIPT","AUDIO","VIDEO"];function Le(e){return F(e,ce)}function Re(e){return ue(e,ce)}function F(e,t){return t.indexOf(e.nodeName)>=0}function ue(e,t){return e.getElementsByTagName&&t.some(function(n){return e.getElementsByTagName(n).length})}var Oe=[[/\\/g,"\\\\"],[/\*/g,"\\*"],[/^-/g,"\\-"],[/^\+ /g,"\\+ "],[/^(=+)/g,"\\$1"],[/^(#{1,6}) /g,"\\$1 "],[/`/g,"\\`"],[/^~~~/g,"\\~~~"],[/\[/g,"\\["],[/\]/g,"\\]"],[/^>/g,"\\>"],[/_/g,"\\_"],[/^(\d+)\. /g,"$1\\. "]];function de(e){return Oe.reduce(function(t,n){return t.replace(n[0],n[1])},e)}var m={};m.paragraph={filter:"p",replacement:function(e){return`

`+e+`

`}};m.lineBreak={filter:"br",replacement:function(e,t,n){return n.br+`
`}};m.heading={filter:["h1","h2","h3","h4","h5","h6"],replacement:function(e,t,n){var r=Number(t.nodeName.charAt(1));if(n.headingStyle==="setext"&&r<3){var a=I(r===1?"=":"-",e.length);return`

`+e+`
`+a+`

`}else return`

`+I("#",r)+" "+e+`

`}};m.blockquote={filter:"blockquote",replacement:function(e){return e=oe(e).replace(/^/gm,"> "),`

`+e+`

`}};m.list={filter:["ul","ol"],replacement:function(e,t){var n=t.parentNode;return n.nodeName==="LI"&&n.lastElementChild===t?`
`+e:`

`+e+`

`}};m.listItem={filter:"li",replacement:function(e,t,n){var r=n.bulletListMarker+"   ",a=t.parentNode;if(a.nodeName==="OL"){var i=a.getAttribute("start"),o=Array.prototype.indexOf.call(a.children,t);r=(i?Number(i)+o:o+1)+".  "}var l=/\n$/.test(e);return e=oe(e)+(l?`
`:""),e=e.replace(/\n/gm,`
`+" ".repeat(r.length)),r+e+(t.nextSibling?`
`:"")}};m.indentedCodeBlock={filter:function(e,t){return t.codeBlockStyle==="indented"&&e.nodeName==="PRE"&&e.firstChild&&e.firstChild.nodeName==="CODE"},replacement:function(e,t,n){return`

    `+t.firstChild.textContent.replace(/\n/g,`
    `)+`

`}};m.fencedCodeBlock={filter:function(e,t){return t.codeBlockStyle==="fenced"&&e.nodeName==="PRE"&&e.firstChild&&e.firstChild.nodeName==="CODE"},replacement:function(e,t,n){for(var r=t.firstChild.getAttribute("class")||"",a=(r.match(/language-(\S+)/)||[null,""])[1],i=t.firstChild.textContent,o=n.fence.charAt(0),l=3,s=new RegExp("^"+o+"{3,}","gm"),c;c=s.exec(i);)c[0].length>=l&&(l=c[0].length+1);var h=I(o,l);return`

`+h+a+`
`+i.replace(/\n$/,"")+`
`+h+`

`}};m.horizontalRule={filter:"hr",replacement:function(e,t,n){return`

`+n.hr+`

`}};m.inlineLink={filter:function(e,t){return t.linkStyle==="inlined"&&e.nodeName==="A"&&e.getAttribute("href")},replacement:function(e,t){var n=j(t.getAttribute("href")),r=q(N(t.getAttribute("title"))),a=r?' "'+r+'"':"";return"["+e+"]("+n+a+")"}};m.referenceLink={filter:function(e,t){return t.linkStyle==="referenced"&&e.nodeName==="A"&&e.getAttribute("href")},replacement:function(e,t,n){var r=j(t.getAttribute("href")),a=N(t.getAttribute("title"));a&&(a=' "'+q(a)+'"');var i,o;switch(n.linkReferenceStyle){case"collapsed":i="["+e+"][]",o="["+e+"]: "+r+a;break;case"shortcut":i="["+e+"]",o="["+e+"]: "+r+a;break;default:var l=this.references.length+1;i="["+e+"]["+l+"]",o="["+l+"]: "+r+a}return this.references.push(o),i},references:[],append:function(e){var t="";return this.references.length&&(t=`

`+this.references.join(`
`)+`

`,this.references=[]),t}};m.emphasis={filter:["em","i"],replacement:function(e,t,n){return e.trim()?n.emDelimiter+e+n.emDelimiter:""}};m.strong={filter:["strong","b"],replacement:function(e,t,n){return e.trim()?n.strongDelimiter+e+n.strongDelimiter:""}};m.code={filter:function(e){var t=e.previousSibling||e.nextSibling,n=e.parentNode.nodeName==="PRE"&&!t;return e.nodeName==="CODE"&&!n},replacement:function(e){if(!e)return"";e=e.replace(/\r?\n|\r/g," ");for(var t=/^`|^ .*?[^ ].* $|`$/.test(e)?" ":"",n="`",r=e.match(/`+/gm)||[];r.indexOf(n)!==-1;)n=n+"`";return n+t+e+t+n}};m.image={filter:"img",replacement:function(e,t){var n=de(N(t.getAttribute("alt"))),r=j(t.getAttribute("src")||""),a=N(t.getAttribute("title")),i=a?' "'+q(a)+'"':"";return r?"!["+n+"]("+r+i+")":""}};function N(e){return e?e.replace(/(\n+\s*)+/g,`
`):""}function j(e){var t=e.replace(/([<>()])/g,"\\$1");return t.indexOf(" ")>=0?"<"+t+">":t}function q(e){return e.replace(/"/g,'\\"')}function fe(e){this.options=e,this._keep=[],this._remove=[],this.blankRule={replacement:e.blankReplacement},this.keepReplacement=e.keepReplacement,this.defaultRule={replacement:e.defaultReplacement},this.array=[];for(var t in e.rules)this.array.push(e.rules[t])}fe.prototype={add:function(e,t){this.array.unshift(t)},keep:function(e){this._keep.unshift({filter:e,replacement:this.keepReplacement})},remove:function(e){this._remove.unshift({filter:e,replacement:function(){return""}})},forNode:function(e){if(e.isBlank)return this.blankRule;var t;return(t=O(this.array,e,this.options))||(t=O(this._keep,e,this.options))||(t=O(this._remove,e,this.options))?t:this.defaultRule},forEach:function(e){for(var t=0;t<this.array.length;t++)e(this.array[t],t)}};function O(e,t,n){for(var r=0;r<e.length;r++){var a=e[r];if(De(a,t,n))return a}}function De(e,t,n){var r=e.filter;if(typeof r=="string"){if(r===t.nodeName.toLowerCase())return!0}else if(Array.isArray(r)){if(r.indexOf(t.nodeName.toLowerCase())>-1)return!0}else if(typeof r=="function"){if(r.call(e,t,n))return!0}else throw new TypeError("`filter` needs to be a string, array, or function")}function Be(e){var t=e.element,n=e.isBlock,r=e.isVoid,a=e.isPre||function(k){return k.nodeName==="PRE"};if(!(!t.firstChild||a(t))){for(var i=null,o=!1,l=null,s=G(l,t,a);s!==t;){if(s.nodeType===3||s.nodeType===4){var c=s.data.replace(/[ \r\n\t]+/g," ");if((!i||/ $/.test(i.data))&&!o&&c[0]===" "&&(c=c.substr(1)),!c){s=D(s);continue}s.data=c,i=s}else if(s.nodeType===1)n(s)||s.nodeName==="BR"?(i&&(i.data=i.data.replace(/ $/,"")),i=null,o=!1):r(s)||a(s)?(i=null,o=!0):i&&(o=!1);else{s=D(s);continue}var h=G(l,s,a);l=s,s=h}i&&(i.data=i.data.replace(/ $/,""),i.data||D(i))}}function D(e){var t=e.nextSibling||e.parentNode;return e.parentNode.removeChild(e),t}function G(e,t,n){return e&&e.parentNode===t||n(t)?t.nextSibling||t.parentNode:t.firstChild||t.nextSibling||t.parentNode}var J=typeof window<"u"?window:{};function _e(){var e=J.DOMParser,t=!1;try{new e().parseFromString("","text/html")&&(t=!0)}catch{}return t}function $e(){var e=function(){};return Ie()?e.prototype.parseFromString=function(t){var n=new window.ActiveXObject("htmlfile");return n.designMode="on",n.open(),n.write(t),n.close(),n}:e.prototype.parseFromString=function(t){var n=document.implementation.createHTMLDocument("");return n.open(),n.write(t),n.close(),n},e}function Ie(){var e=!1;try{document.implementation.createHTMLDocument("").open()}catch{J.ActiveXObject&&(e=!0)}return e}var Pe=_e()?J.DOMParser:$e();function He(e,t){var n;if(typeof e=="string"){var r=We().parseFromString('<x-turndown id="turndown-root">'+e+"</x-turndown>","text/html");n=r.getElementById("turndown-root")}else n=e.cloneNode(!0);return Be({element:n,isBlock:U,isVoid:se,isPre:t.preformattedCode?Ue:null}),n}var B;function We(){return B=B||new Pe,B}function Ue(e){return e.nodeName==="PRE"||e.nodeName==="CODE"}function Fe(e,t){return e.isBlock=U(e),e.isCode=e.nodeName==="CODE"||e.parentNode.isCode,e.isBlank=je(e),e.flankingWhitespace=qe(e,t),e}function je(e){return!se(e)&&!Le(e)&&/^\s*$/i.test(e.textContent)&&!Se(e)&&!Re(e)}function qe(e,t){if(e.isBlock||t.preformattedCode&&e.isCode)return{leading:"",trailing:""};var n=Je(e.textContent);return n.leadingAscii&&z("left",e,t)&&(n.leading=n.leadingNonAscii),n.trailingAscii&&z("right",e,t)&&(n.trailing=n.trailingNonAscii),{leading:n.leading,trailing:n.trailing}}function Je(e){var t=e.match(/^(([ \t\r\n]*)(\s*))(?:(?=\S)[\s\S]*\S)?((\s*?)([ \t\r\n]*))$/);return{leading:t[1],leadingAscii:t[2],leadingNonAscii:t[3],trailing:t[4],trailingNonAscii:t[5],trailingAscii:t[6]}}function z(e,t,n){var r,a,i;return e==="left"?(r=t.previousSibling,a=/ $/):(r=t.nextSibling,a=/^ /),r&&(r.nodeType===3?i=a.test(r.nodeValue):n.preformattedCode&&r.nodeName==="CODE"?i=!1:r.nodeType===1&&!U(r)&&(i=a.test(r.textContent))),i}var Ve=Array.prototype.reduce;function S(e){if(!(this instanceof S))return new S(e);var t={rules:m,headingStyle:"setext",hr:"* * *",bulletListMarker:"*",codeBlockStyle:"indented",fence:"```",emDelimiter:"_",strongDelimiter:"**",linkStyle:"inlined",linkReferenceStyle:"full",br:"  ",preformattedCode:!1,blankReplacement:function(n,r){return r.isBlock?`

`:""},keepReplacement:function(n,r){return r.isBlock?`

`+r.outerHTML+`

`:r.outerHTML},defaultReplacement:function(n,r){return r.isBlock?`

`+n+`

`:n}};this.options=Ae({},t,e),this.rules=new fe(this.options)}S.prototype={turndown:function(e){if(!Ge(e))throw new TypeError(e+" is not a string, or an element/document/fragment node.");if(e==="")return"";var t=me.call(this,new He(e,this.options));return Xe.call(this,t)},use:function(e){if(Array.isArray(e))for(var t=0;t<e.length;t++)this.use(e[t]);else if(typeof e=="function")e(this);else throw new TypeError("plugin must be a Function or an Array of Functions");return this},addRule:function(e,t){return this.rules.add(e,t),this},keep:function(e){return this.rules.keep(e),this},remove:function(e){return this.rules.remove(e),this},escape:function(e){return de(e)}};function me(e){var t=this;return Ve.call(e.childNodes,function(n,r){r=new Fe(r,t.options);var a="";return r.nodeType===3?a=r.isCode?r.nodeValue:t.escape(r.nodeValue):r.nodeType===1&&(a=Ye.call(t,r)),pe(n,a)},"")}function Xe(e){var t=this;return this.rules.forEach(function(n){typeof n.append=="function"&&(e=pe(e,n.append(t.options)))}),e.replace(/^[\t\r\n]+/,"").replace(/[\t\r\n\s]+$/,"")}function Ye(e){var t=this.rules.forNode(e),n=me.call(this,e),r=e.flankingWhitespace;return(r.leading||r.trailing)&&(n=n.trim()),r.leading+t.replacement(n,e,this.options)+r.trailing}function pe(e,t){var n=ie(e),r=ae(t),a=Math.max(e.length-n.length,t.length-r.length),i=`

`.substring(0,a);return n+i+r}function Ge(e){return e!=null&&(typeof e=="string"||e.nodeType&&(e.nodeType===1||e.nodeType===9||e.nodeType===11))}var K=/highlight-(?:text|source)-([a-z0-9]+)/;function ze(e){e.addRule("highlightedCodeBlock",{filter:function(t){var n=t.firstChild;return t.nodeName==="DIV"&&K.test(t.className)&&n&&n.nodeName==="PRE"},replacement:function(t,n,r){var a=n.className||"",i=(a.match(K)||[null,""])[1];return`

`+r.fence+i+`
`+n.firstChild.textContent+`
`+r.fence+`

`}})}function Ke(e){e.addRule("strikethrough",{filter:["del","s","strike"],replacement:function(t){return"~"+t+"~"}})}var Qe=Array.prototype.indexOf,Ze=Array.prototype.every,v={};v.tableCell={filter:["th","td"],replacement:function(e,t){return he(e,t)}};v.tableRow={filter:"tr",replacement:function(e,t){var n="",r={left:":--",right:"--:",center:":-:"};if(V(t))for(var a=0;a<t.childNodes.length;a++){var i="---",o=(t.childNodes[a].getAttribute("align")||"").toLowerCase();o&&(i=r[o]||i),n+=he(i,t.childNodes[a])}return`
`+e+(n?`
`+n:"")}};v.table={filter:function(e){return e.nodeName==="TABLE"&&V(e.rows[0])},replacement:function(e){return e=e.replace(`

`,`
`),`

`+e+`

`}};v.tableSection={filter:["thead","tbody","tfoot"],replacement:function(e){return e}};function V(e){var t=e.parentNode;return t.nodeName==="THEAD"||t.firstChild===e&&(t.nodeName==="TABLE"||et(t))&&Ze.call(e.childNodes,function(n){return n.nodeName==="TH"})}function et(e){var t=e.previousSibling;return e.nodeName==="TBODY"&&(!t||t.nodeName==="THEAD"&&/^\s*$/i.test(t.textContent))}function he(e,t){var n=Qe.call(t.parentNode.childNodes,t),r=" ";return n===0&&(r="| "),r+e+" |"}function tt(e){e.keep(function(n){return n.nodeName==="TABLE"&&!V(n.rows[0])});for(var t in v)e.addRule(t,v[t])}function nt(e){e.addRule("taskListItems",{filter:function(t){return t.type==="checkbox"&&t.parentNode.nodeName==="LI"},replacement:function(t,n){return(n.checked?"[x]":"[ ]")+" "}})}function rt(e){e.use([ze,Ke,tt,nt])}const at=[[/α/g,"\\alpha"],[/β/g,"\\beta"],[/γ/g,"\\gamma"],[/δ/g,"\\delta"],[/ε/g,"\\varepsilon"],[/θ/g,"\\theta"],[/λ/g,"\\lambda"],[/μ/g,"\\mu"],[/π/g,"\\pi"],[/σ/g,"\\sigma"],[/φ/g,"\\varphi"],[/ω/g,"\\omega"],[/∞/g,"\\infty"],[/∑/g,"\\sum"],[/∫/g,"\\int"],[/√/g,"\\sqrt"],[/±/g,"\\pm"],[/×/g,"\\times"],[/÷/g,"\\div"],[/≤/g,"\\leq"],[/≥/g,"\\geq"],[/≠/g,"\\neq"],[/≈/g,"\\approx"],[/²/g,"^2"],[/³/g,"^3"]];function it(e){if(!e)return!1;if(e.matches("math, mjx-container, [data-math], [data-latex], [data-tex]")||e.matches(".katex, .katex-display, .MathJax, .MathJax_Display, .MathJax_CHTML, .MathJax_MathML, .mjx-chtml, .MJXc-display"))return!0;const t=pt(e);return/\b(math-|equation|formula)\b/.test(t)}function _(e){if(!(e instanceof Element))return null;const t=e.closest(".katex, .katex-display, mjx-container, .MathJax_Display, .MJXc-display, .MathJax, .mjx-chtml, .MathJax_CHTML, .MathJax_MathML, [data-math], math, [data-latex], [data-tex]");if(t)return t;let n=e,r=null;for(let a=0;n&&a<20;a+=1)it(n)&&(r=n),n=n.parentElement;return r}function P(e){var h;const t=dt(e);if(t)return t;const n=L(e,["data-math"]);if(n)return{latex:n,mode:y(e),source:"data-math"};const r=st(e);if(r)return r;const a=ct(e);if(a)return a;const i=ut(e);if(i)return i;const o=L(e,["data-latex","data-tex","aria-label","title"]);if(o)return{latex:o,mode:y(e),source:"attribute"};const l=((h=e.textContent)==null?void 0:h.trim())??"";if(!l)return null;const s=mt(l);if(s)return{latex:s.latex,mode:s.mode,source:"delimited-text"};const c=lt(l);return c!==l?{latex:c,mode:y(e),source:"unicode-fallback"}:null}function ot(e){return e==="display"?"$$":"$"}function ge(e,t){const n=ot(t);return`${n}${e.trim()}${n}`}function lt(e){let t=e;for(const[n,r]of at)t=t.replace(n,r);return t=t.replace(/(\b\w+)\^(\w+)/g,"$1^{$2}"),t=t.replace(/\be\s*i\s*(\\pi|\\theta|[a-zA-Z]+)/g,"e^{i$1}"),t}function y(e){if(e.matches(".katex-display, .MathJax_Display, .MJXc-display")||e.tagName.toLowerCase()==="mjx-container"&&e.hasAttribute("display")||e.matches("img.mwe-math-fallback-image-display"))return"display";const t=e.parentElement;if(t!=null&&t.classList.contains("katex-display"))return"display";if(e.hasAttribute("data-math"))return e.tagName.toLowerCase()==="div"?"display":"inline";const n=ht(e);return n&&n.display==="block"?"display":"inline"}function st(e){var a;const t=e.closest(".katex")??(e.matches(".katex-display")?e.querySelector(".katex"):null);if(!t)return null;const n=t.querySelector('annotation[encoding="application/x-tex"], annotation[encoding="application/x-latex"], annotation[encoding="application/tex"]'),r=((a=n==null?void 0:n.textContent)==null?void 0:a.trim())||L(t,["data-latex","data-tex","aria-label","title"]);return r?{latex:r,mode:y(t),source:"katex"}:null}function ct(e){var o,l,s;const t=e.closest("mjx-container, .MathJax_Display, .MJXc-display, .MathJax, .mjx-chtml, .MathJax_CHTML, .MathJax_MathML");if(!t)return null;const n=t.querySelector('script[type*="math/tex"]');if((o=n==null?void 0:n.textContent)!=null&&o.trim())return{latex:n.textContent.trim(),mode:y(t),source:"mathjax-script-child"};const r=ft(t);if((l=r==null?void 0:r.textContent)!=null&&l.trim())return{latex:r.textContent.trim(),mode:r.type.includes("mode=display")?"display":y(t),source:"mathjax-script-sibling"};const a=t.querySelector("mjx-assistive-mml annotation");if((s=a==null?void 0:a.textContent)!=null&&s.trim())return{latex:a.textContent.trim(),mode:y(t),source:"mathjax-assistive"};const i=L(t,["data-latex","data-tex","aria-label","title"]);return i?{latex:i,mode:y(t),source:"mathjax-attribute"}:null}function ut(e){var r;const t=e.closest("math")??e.querySelector("math");if(!t)return null;const n=t.querySelector('annotation[encoding="application/x-tex"], annotation[encoding="application/x-latex"], annotation[encoding="application/tex"]');return(r=n==null?void 0:n.textContent)!=null&&r.trim()?{latex:n.textContent.trim(),mode:y(t),source:"mathml-annotation"}:null}function dt(e){var r;if(!(e instanceof HTMLImageElement)||!e.matches("img.mwe-math, img.mwe-math-fallback-image-inline, img.mwe-math-fallback-image-display"))return null;const t=(r=e.getAttribute("alt"))==null?void 0:r.trim();if(!t)return null;const n=t.match(/^\{\\displaystyle\s*([\s\S]*?)\}$/);return{latex:((n==null?void 0:n[1])??t).trim(),mode:y(e),source:"wikipedia-alt"}}function L(e,t){var n;for(const r of t){const a=(n=e.getAttribute(r))==null?void 0:n.trim();if(a&&(r==="data-math"||a.includes("\\")||/[$^_{}]/.test(a)))return a}return null}function ft(e){let t=e;for(let n=0;t&&n<8;n+=1)if(t=t.nextElementSibling,t instanceof HTMLScriptElement&&t.type.includes("math/tex"))return t;t=e;for(let n=0;t&&n<4;n+=1)if(t=t.previousElementSibling,t instanceof HTMLScriptElement&&t.type.includes("math/tex"))return t;return null}function mt(e){return e.startsWith("$$")&&e.endsWith("$$")&&e.length>4?{latex:e.slice(2,-2).trim(),mode:"display"}:e.startsWith("\\[")&&e.endsWith("\\]")&&e.length>4?{latex:e.slice(2,-2).trim(),mode:"display"}:e.startsWith("$")&&e.endsWith("$")&&e.length>2?{latex:e.slice(1,-1).trim(),mode:"inline"}:e.startsWith("\\(")&&e.endsWith("\\)")&&e.length>4?{latex:e.slice(2,-2).trim(),mode:"inline"}:null}function pt(e){const t=e.className;return typeof t=="string"?t:t&&typeof t.baseVal=="string"?t.baseVal:""}function ht(e){try{return window.getComputedStyle(e)}catch{return null}}function gt(){const e=window.getSelection();if(!e||e.rangeCount===0||e.toString().trim()==="")return"";const t=document.createElement("div");for(let n=0;n<e.rangeCount;n+=1)t.append(e.getRangeAt(n).cloneContents());return t.innerHTML}function ye(){const e=gt();return e?bt(e):""}function yt(){const e=document.body;if(!e)return"";const t=Mt(),n=M(e);return[t,n].filter(Boolean).join(`

---

`)}function M(e){const t=e.cloneNode(!0);return t instanceof Element?we(t):""}function wt(e){return e.map(t=>M(t)).map(t=>t.trim()).filter(Boolean).join(`

---

`)}function bt(e){const t=document.createElement("div");return t.innerHTML=e,we(t)}function we(e){xt(e),Et(e),kt(e);const t=new S({headingStyle:"atx",codeBlockStyle:"fenced",bulletListMarker:"-",emDelimiter:"*"});t.use(rt),t.addRule("latexMarker",{filter:r=>r.nodeType===Node.ELEMENT_NODE&&r.classList.contains("copy-web-to-ai-latex-marker"),replacement:(r,a)=>{const i=a,o=i.textContent??"";return i.getAttribute("data-display-mode")==="display"?`

${o}

`:o}}),t.addRule("preserveLineBreaks",{filter:"br",replacement:()=>`
`}),t.addRule("disabledTaskCheckbox",{filter:r=>r.nodeName==="INPUT"&&r.type==="checkbox",replacement:(r,a)=>a.checked?"[x] ":"[ ] "});const n=t.turndown(e.innerHTML);return Tt(n)}function xt(e){const t=vt(e);for(const n of t){if(!e.contains(n))continue;const r=P(n);if(!r)continue;const a=document.createElement(r.mode==="display"?"div":"span");a.className="copy-web-to-ai-latex-marker",a.dataset.displayMode=r.mode,a.textContent=ge(r.latex,r.mode),n.replaceWith(a)}}function vt(e){const t=[".katex-display",".katex","mjx-container",".MathJax_Display",".MJXc-display",".MathJax",".mjx-chtml",".MathJax_CHTML",".MathJax_MathML","[data-math]","math","[data-latex]","[data-tex]","img.mwe-math","img.mwe-math-fallback-image-inline","img.mwe-math-fallback-image-display"].join(","),n=Array.from(e.querySelectorAll(t));return n.filter(r=>!n.some(a=>a!==r&&a.contains(r)))}function Et(e){e.querySelectorAll(["script","style","noscript","template","iframe","object","embed","canvas","[hidden]","[inert]","[aria-hidden='true']","dialog:not([open])","#copy-web-to-ai-ui-root","svg[aria-hidden='true']","[aria-hidden='true'] .katex-html",".katex-html",".katex-mathml","mjx-assistive-mml","[data-testid='copy-turn-action-button']","[data-testid='good-response-turn-action-button']","[data-testid='bad-response-turn-action-button']","button","[role='button'][aria-label*='Copy']","[role='button'][aria-label*='复制']"].join(",")).forEach(t=>t.remove())}function kt(e){e.querySelectorAll("a[href]").forEach(t=>{try{t.setAttribute("href",t.href)}catch{}}),e.querySelectorAll("img[src]").forEach(t=>{try{t.setAttribute("src",t.src)}catch{}})}function Mt(){const e=[],t=document.title.trim();t&&e.push(`# ${Ct(t)}`);const n=window.location.href;return n&&!n.startsWith("about:")&&e.push(`Source: ${n}`),e.join(`

`)}function Ct(e){return e.replace(/\s+/g," ").replace(/^#+\s*/,"")}function Tt(e){return e.replace(/\u00a0/g," ").replace(/[ \t]+\n/g,`
`).replace(/^(\s*[-*+]) {2,}/gm,"$1 ").replace(/\n{3,}/g,`

`).replace(/\n?(\$\$[\s\S]+?\$\$)\n?/g,`

$1

`).replace(/\n{3,}/g,`

`).trim()}const be=['[data-message-author-role="assistant"]','[data-testid^="conversation-turn-"]:has([data-message-author-role="assistant"])',".agent-turn",".model-response-text",".markdown.prose",".ds-markdown","[data-response-index]"],At=['[data-message-author-role="user"]','[data-message-author-role="assistant"]','[data-testid^="conversation-turn-"]',"article","[role='article']"],Nt=["main",'[role="main"]','[data-testid="conversation-panel"]',".conversation",".chat-container"];let H=null;function St(){document.addEventListener("pointermove",e=>{e.target instanceof Element&&(H=e.target)},{capture:!0,passive:!0})}function Lt(){const e=Dt();return e?M(e):""}function Rt(){const e=X();return e?M(e):""}function Ot(){const e=Bt();if(e.length>0)return wt(e);const t=Y();return t?M(t):""}function Q(){return yt()}function Dt(){const e=X();if(e)return e;if(H){const t=ve(H);if(t&&E(t))return t}return xe().at(-1)??null}function X(){const e=window.getSelection();if(!e||e.rangeCount===0||e.isCollapsed)return null;const t=$t(e);for(const n of t){const r=ve(n);if(r&&E(r))return r}return null}function xe(){const e=Y()??document.body,n=ke(be.flatMap(r=>Ee(e,r))).filter(r=>{var a;return((a=r.textContent)==null?void 0:a.trim())||r.querySelector("img, canvas, math, .katex, mjx-container")}).filter(E);return n.length>0?n:Array.from(e.querySelectorAll("article, [role='article']")).filter(E)}function Bt(){const e=Y()??document.body,n=ke(At.flatMap(r=>Ee(e,r))).filter(r=>{var a;return((a=r.textContent)==null?void 0:a.trim())||r.querySelector("img, canvas, math, .katex, mjx-container")}).filter(E);return n.length>0?n:xe()}function ve(e){for(const t of be){const n=_t(e,t);if(n)return n}return null}function Y(){for(const e of Nt){const t=document.querySelector(e);if(t&&E(t))return t}return document.body}function Ee(e,t){try{return Array.from(e.querySelectorAll(t))}catch{return[]}}function _t(e,t){try{return e.closest(t)}catch{return null}}function ke(e){const t=[];for(const n of e)t.some(r=>r===n||r.contains(n))||t.push(n);return t.sort(It)}function $t(e){const t=[],n=r=>{const a=r instanceof Element?r:(r==null?void 0:r.parentElement)??null;a&&!t.includes(a)&&t.push(a)};n(e.anchorNode),n(e.focusNode);for(let r=0;r<e.rangeCount;r+=1)n(e.getRangeAt(r).commonAncestorContainer);return t}function It(e,t){if(e===t)return 0;const n=e.compareDocumentPosition(t);return n&Node.DOCUMENT_POSITION_PRECEDING?1:n&Node.DOCUMENT_POSITION_FOLLOWING?-1:0}function E(e){const t=e.getBoundingClientRect();if(t.width<=0||t.height<=0||t.bottom<0||t.top>window.innerHeight)return!1;const n=window.getComputedStyle(e);return n.visibility!=="hidden"&&n.display!=="none"&&n.opacity!=="0"}const d="copy-web-to-ai-ui-root";let $=null;async function C(e){if(!e.trim())throw new Error("没有可复制的内容");try{await navigator.clipboard.writeText(e);return}catch{const t=document.createElement("textarea");t.value=e,t.style.position="fixed",t.style.left="-9999px",t.style.top="0",t.setAttribute("readonly","true"),document.body.append(t),t.select();const n=document.execCommand("copy");if(t.remove(),!n)throw new Error("剪贴板写入失败")}}function Pt(e,t){if(!e.trim())throw new Error("没有可下载的内容");const n=Ht(t),r=new Blob([e],{type:"text/markdown;charset=utf-8"}),a=URL.createObjectURL(r),i=document.createElement("a");return i.href=a,i.download=n,i.style.display="none",document.body.append(i),i.click(),i.remove(),window.setTimeout(()=>URL.revokeObjectURL(a),3e4),n}function f(e,t="info"){const n=R();let r=n.querySelector(".copy-web-to-ai-toast");r||(r=document.createElement("div"),r.className="copy-web-to-ai-toast",n.append(r)),r.textContent=e,r.dataset.tone=t,r.dataset.visible="true",$&&window.clearTimeout($),$=window.setTimeout(()=>{r==null||r.removeAttribute("data-visible")},2200)}function R(){let e=document.getElementById(d);if(e)return e;e=document.createElement("div"),e.id=d,document.documentElement.append(e);const t=document.createElement("style");return t.textContent=`
    #${d} {
      all: initial;
      color-scheme: light dark;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      position: fixed;
      inset: 0;
      pointer-events: none;
      z-index: 2147483647;
    }

    #${d} .copy-web-to-ai-toast {
      position: fixed;
      left: 50%;
      bottom: 28px;
      transform: translateX(-50%) translateY(12px);
      max-width: min(420px, calc(100vw - 32px));
      padding: 10px 14px;
      border-radius: 8px;
      background: rgba(28, 28, 32, 0.94);
      color: #fff;
      box-shadow: 0 8px 28px rgba(0, 0, 0, 0.24);
      font: 13px/1.4 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      opacity: 0;
      pointer-events: none;
      transition: opacity 160ms ease, transform 160ms ease;
      white-space: normal;
    }

    #${d} .copy-web-to-ai-toast[data-visible="true"] {
      opacity: 1;
      transform: translateX(-50%) translateY(0);
    }

    #${d} .copy-web-to-ai-toast[data-tone="ok"] {
      background: rgba(28, 116, 64, 0.96);
    }

    #${d} .copy-web-to-ai-toast[data-tone="error"] {
      background: rgba(178, 45, 45, 0.96);
    }

    #${d} .copy-web-to-ai-formula-button {
      position: fixed;
      min-width: 48px;
      height: 28px;
      padding: 0 10px;
      border: 1px solid rgba(255, 255, 255, 0.24);
      border-radius: 8px;
      background: rgba(25, 27, 32, 0.94);
      color: #fff;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.22);
      font: 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      cursor: pointer;
      pointer-events: auto;
    }

    #${d} .copy-web-to-ai-selection-toolbar {
      position: fixed;
      display: flex;
      gap: 6px;
      align-items: center;
      min-height: 32px;
      padding: 5px;
      border: 1px solid rgba(255, 255, 255, 0.20);
      border-radius: 8px;
      background: rgba(25, 27, 32, 0.96);
      box-shadow: 0 10px 28px rgba(0, 0, 0, 0.24);
      opacity: 0;
      pointer-events: none;
      transform: translateX(-50%) translateY(4px);
      transition: opacity 120ms ease, transform 120ms ease;
    }

    #${d} .copy-web-to-ai-selection-toolbar[data-visible="true"] {
      opacity: 1;
      pointer-events: auto;
      transform: translateX(-50%) translateY(0);
    }

    #${d} .copy-web-to-ai-selection-toolbar button {
      min-width: 0;
      min-height: 28px;
      margin: 0;
      padding: 0 9px;
      border: 0;
      border-radius: 6px;
      background: transparent;
      color: #fff;
      cursor: pointer;
      font: 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      white-space: nowrap;
      pointer-events: auto;
    }

    #${d} .copy-web-to-ai-selection-toolbar button:hover {
      background: rgba(255, 255, 255, 0.14);
    }

    #${d} .copy-web-to-ai-selection-toolbar button[hidden] {
      display: none;
    }

    #${d} .copy-web-to-ai-ocr-layer {
      position: fixed;
      inset: 0;
      cursor: crosshair;
      background: rgba(0, 0, 0, 0.16);
      pointer-events: auto;
    }

    #${d} .copy-web-to-ai-ocr-box {
      position: fixed;
      border: 2px solid #ffffff;
      background: rgba(59, 130, 246, 0.18);
      box-shadow: 0 0 0 9999px rgba(0, 0, 0, 0.20);
    }

    #${d} .copy-web-to-ai-ocr-hint {
      position: fixed;
      top: 16px;
      left: 50%;
      transform: translateX(-50%);
      padding: 8px 12px;
      border-radius: 8px;
      background: rgba(25, 27, 32, 0.94);
      color: #fff;
      font: 13px/1.35 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.22);
    }
  `,e.append(t),e}function Ht(e){const n=(document.title.trim()||e).replace(/[\\/:*?"<>|#]+/g," ").replace(/\s+/g,"-").replace(/^-+|-+$/g,"").slice(0,80).toLowerCase(),r=new Date().toISOString().replace(/[:.]/g,"-").slice(0,19);return`${n||"copy-web-to-ai"}-${r}.md`}function Wt(){return new Promise(e=>{const t=R(),n=document.createElement("div"),r=document.createElement("div"),a=document.createElement("div");n.className="copy-web-to-ai-ocr-layer",r.className="copy-web-to-ai-ocr-box",a.className="copy-web-to-ai-ocr-hint",a.textContent="拖拽框选要 OCR 的可见区域，按 Esc 取消",n.append(r,a),t.append(n);let i=0,o=0,l=!1;const s=()=>{n.remove(),window.removeEventListener("keydown",h,!0),window.removeEventListener("blur",c,!0)},c=()=>{s(),e(null)},h=u=>{u.key==="Escape"&&(u.preventDefault(),c())},k=u=>{const g=Z(i,o,u.clientX,u.clientY);r.style.left=`${g.x}px`,r.style.top=`${g.y}px`,r.style.width=`${g.width}px`,r.style.height=`${g.height}px`};n.addEventListener("pointerdown",u=>{u.preventDefault(),l=!0,i=u.clientX,o=u.clientY,n.setPointerCapture(u.pointerId),k(u)}),n.addEventListener("pointermove",u=>{l&&(u.preventDefault(),k(u))}),n.addEventListener("pointerup",u=>{if(!l)return;u.preventDefault(),l=!1;const g=Z(i,o,u.clientX,u.clientY);if(s(),g.width<8||g.height<8){f("框选区域太小","error"),e(null);return}e({...g,viewportWidth:window.innerWidth,viewportHeight:window.innerHeight})}),window.addEventListener("keydown",h,!0),window.addEventListener("blur",c,!0)})}function Z(e,t,n,r){const a=Math.max(0,Math.min(e,n)),i=Math.max(0,Math.min(t,r)),o=Math.min(window.innerWidth,Math.max(e,n)),l=Math.min(window.innerHeight,Math.max(t,r));return{x:a,y:i,width:o-a,height:l-i}}const Ut=2;let p=null,b=null,ee=!1;function Ft(){ee||(ee=!0,document.addEventListener("selectionchange",T),document.addEventListener("mouseup",T,!0),document.addEventListener("keyup",e=>{["Shift","ArrowLeft","ArrowRight","ArrowUp","ArrowDown","Home","End"].includes(e.key)&&T()}),document.addEventListener("scroll",x,!0),window.addEventListener("resize",x),window.addEventListener("blur",x),T())}function jt(){if(p)return p;const e=R();return p=document.createElement("div"),p.className="copy-web-to-ai-selection-toolbar",p.setAttribute("role","toolbar"),p.setAttribute("aria-label","Copy Web to AI 选区工具"),p.innerHTML=`
    <button type="button" data-tool="copy">复制 Markdown</button>
    <button type="button" data-tool="answer">复制当前回答</button>
    <button type="button" data-tool="ocr">OCR</button>
  `,p.addEventListener("pointerdown",t=>{t.preventDefault(),t.stopPropagation()}),p.addEventListener("click",t=>{var r;t.preventDefault(),t.stopPropagation();const n=(r=t.target)==null?void 0:r.closest("button[data-tool]");n&&Jt(n.dataset.tool??"")}),e.append(p),p}function T(){b&&window.clearTimeout(b),b=window.setTimeout(qt,80)}function qt(){const e=Me();if(!e){x();return}const t=jt(),n=t.querySelector('[data-tool="answer"]');n&&(n.hidden=!e.hasAssistantAnswer),t.dataset.visible="true",Gt(t,e.rect)}function x(){b&&(window.clearTimeout(b),b=null),p==null||p.removeAttribute("data-visible")}async function Jt(e){try{if(e==="copy"){await te(ye(),"已复制选区 Markdown");return}if(e==="answer"){await te(Rt(),"已复制当前回答");return}e==="ocr"&&await Vt()}catch(t){f(t instanceof Error?t.message:"操作失败","error")}}async function te(e,t){if(!e.trim())throw new Error("没有找到可复制内容");await C(e),f(t,"ok"),x()}async function Vt(){const e=Me();if(!e)throw new Error("没有可 OCR 的选区");const t={x:e.rect.left,y:e.rect.top,width:e.rect.width,height:e.rect.height,viewportWidth:window.innerWidth,viewportHeight:window.innerHeight};f("正在上传选区到 MinerU OCR...","info");const n=await chrome.runtime.sendMessage({type:"RUN_MINERU_OCR",rect:t});if(!n.ok)throw new Error(n.error);await C(n.markdown),f("OCR 结果已复制","ok"),x()}function Me(){const e=window.getSelection();if(!e||e.rangeCount===0||e.isCollapsed||e.toString().trim().length<Ut||Yt(e))return null;const t=Xt(e);return!t||t.width<4||t.height<4?null:{rect:t,hasAssistantAnswer:!!X()}}function Xt(e){const t=[];for(let o=0;o<e.rangeCount;o+=1)t.push(...Array.from(e.getRangeAt(o).getClientRects()).filter(l=>!(l.width<=0||l.height<=0||l.bottom<0||l.top>window.innerHeight||l.right<0||l.left>window.innerWidth)));if(t.length===0)return null;const n=Math.max(0,Math.min(...t.map(o=>o.left))),r=Math.max(0,Math.min(...t.map(o=>o.top))),a=Math.min(window.innerWidth,Math.max(...t.map(o=>o.right))),i=Math.min(window.innerHeight,Math.max(...t.map(o=>o.bottom)));return new DOMRect(n,r,a-n,i-r)}function Yt(e){const t=document.activeElement;if(t&&ne(t))return!0;for(let n=0;n<e.rangeCount;n+=1){const r=e.getRangeAt(n).commonAncestorContainer,a=r instanceof Element?r:r.parentElement;if(a&&ne(a))return!0}return!1}function ne(e){return!!e.closest("input, textarea, select, [contenteditable='true'], [contenteditable='plaintext-only']")}function Gt(e,t){const r=(e.offsetWidth||260)/2,a=t.left+t.width/2,i=re(a,r+8,window.innerWidth-r-8),o=t.top>46?t.top-40:t.bottom+8;e.style.left=`${i}px`,e.style.top=`${re(o,8,window.innerHeight-40)}px`}function re(e,t,n){return Math.min(n,Math.max(t,e))}const W="copy-web-to-ai-unlock-style";let w=!1;const Ce=["copy","cut","selectstart","selectionchange","contextmenu","mousedown","mouseup","dragstart"];function zt(){return w=!w,w?Qt():Zt(),w}function Kt(){return w}function Qt(){en();for(const e of Ce)document.addEventListener(e,Te,!0);f("已临时解锁当前页面复制","ok")}function Zt(){var e;(e=document.getElementById(W))==null||e.remove();for(const t of Ce)document.removeEventListener(t,Te,!0);f("已关闭解锁复制","info")}function en(){if(document.getElementById(W))return;const e=document.createElement("style");e.id=W,e.textContent=`
    html, body, body * {
      user-select: text !important;
      -webkit-user-select: text !important;
      -moz-user-select: text !important;
      -ms-user-select: text !important;
    }
  `,document.documentElement.append(e)}function Te(e){var n,r;if(!w)return;const t=e.target;if(!(t instanceof Element&&t.closest("#copy-web-to-ai-ui-root"))&&(e.stopImmediatePropagation(),e.type==="copy")){const a=((n=window.getSelection())==null?void 0:n.toString())??"";if(!a.trim())return;const i=e;(r=i.clipboardData)==null||r.setData("text/plain",a),i.clipboardData&&e.preventDefault()}}window.__copyWebToAiLoaded||(window.__copyWebToAiLoaded=!0,St(),Ft(),on(),tn());function tn(){chrome.runtime.onMessage.addListener((e,t,n)=>(nn(e).then(r=>n(r)).catch(r=>{const a=r instanceof Error?r.message:String(r);f(a,"error"),n({ok:!1,error:a})}),!0))}async function nn(e){switch(e.type){case"PING_COPY_WEB_TO_AI":return{ok:!0};case"COPY_SELECTION_MARKDOWN":return A(ye(),"已复制选区 Markdown");case"COPY_ACTIVE_ANSWER":return A(Lt(),"已复制当前回答");case"COPY_VISIBLE_CHAT":return A(Ot(),"已复制可见会话");case"COPY_FULL_PAGE_MARKDOWN":return A(Q(),"已复制整页 Markdown");case"DOWNLOAD_FULL_PAGE_MARKDOWN":return rn(Q(),"page");case"TOGGLE_UNLOCK_COPY":return{ok:!0,enabled:zt()};case"START_REGION_OCR":return an();default:return{ok:!1,error:"未知指令"}}}async function A(e,t){if(!e.trim())throw new Error("没有找到可复制内容");return await C(e),f(t,"ok"),{ok:!0,length:e.length}}async function rn(e,t){if(!e.trim())throw new Error("没有找到可下载内容");const n=Pt(e,t);return f("Markdown 文件已下载","ok"),{ok:!0,length:e.length,filename:n}}async function an(){f("准备框选 OCR 区域","info");const e=await Wt();if(!e)return{ok:!1,cancelled:!0};f("正在上传到 MinerU OCR...","info");const t=await chrome.runtime.sendMessage({type:"RUN_MINERU_OCR",rect:e});if(!t.ok)throw new Error(t.error);return await C(t.markdown),f("OCR 结果已复制","ok"),{ok:!0,length:t.markdown.length}}async function on(){if(!await ln())return;const t=R(),n=document.createElement("button");n.type="button",n.className="copy-web-to-ai-formula-button",n.textContent="复制",n.title="复制 LaTeX",n.style.display="none",t.append(n);let r=null,a=null;const i=()=>{n.style.display="none",r=null},o=()=>{a&&window.clearTimeout(a),a=window.setTimeout(()=>{n.matches(":hover")||i()},120)};document.addEventListener("mouseover",l=>{if(Kt())return;const s=_(l.target);if(!s||s===r||!P(s))return;r=s;const h=s.getBoundingClientRect(),u=Math.min(window.innerWidth-54-8,Math.max(8,h.right+8)),g=Math.min(window.innerHeight-32,Math.max(8,h.top));n.style.left=`${u}px`,n.style.top=`${g}px`,n.style.display="block"},!0),document.addEventListener("mouseout",l=>{const s=_(l.target),c=_(l.relatedTarget);s&&s!==c&&o()},!0),n.addEventListener("mouseleave",o),n.addEventListener("click",async l=>{if(l.preventDefault(),l.stopPropagation(),!r)return;const s=P(r);if(!s){f("没有找到 LaTeX 源码","error");return}try{await C(ge(s.latex,s.mode)),n.textContent="已复制",f("LaTeX 已复制","ok"),window.setTimeout(()=>{n.textContent="复制"},1e3)}catch(c){f(c instanceof Error?c.message:"复制失败","error")}})}async function ln(){try{return(await chrome.storage.local.get({enableFormulaButton:!0})).enableFormulaButton!==!1}catch{return!0}}

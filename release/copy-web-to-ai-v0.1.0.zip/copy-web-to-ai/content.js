function he(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e}function R(e,t){return Array(t+1).join(e)}function G(e){return e.replace(/^\n*/,"")}function z(e){for(var t=e.length;t>0&&e[t-1]===`
`;)t--;return e.substring(0,t)}function K(e){return z(G(e))}var ge=["ADDRESS","ARTICLE","ASIDE","AUDIO","BLOCKQUOTE","BODY","CANVAS","CENTER","DD","DIR","DIV","DL","DT","FIELDSET","FIGCAPTION","FIGURE","FOOTER","FORM","FRAMESET","H1","H2","H3","H4","H5","H6","HEADER","HGROUP","HR","HTML","ISINDEX","LI","MAIN","MENU","NAV","NOFRAMES","NOSCRIPT","OL","OUTPUT","P","PRE","SECTION","TABLE","TBODY","TD","TFOOT","TH","THEAD","TR","UL"];function _(e){return $(e,ge)}var Q=["AREA","BASE","BR","COL","COMMAND","EMBED","HR","IMG","INPUT","KEYGEN","LINK","META","PARAM","SOURCE","TRACK","WBR"];function Z(e){return $(e,Q)}function ye(e){return te(e,Q)}var ee=["A","TABLE","THEAD","TBODY","TFOOT","TH","TD","IFRAME","SCRIPT","AUDIO","VIDEO"];function xe(e){return $(e,ee)}function be(e){return te(e,ee)}function $(e,t){return t.indexOf(e.nodeName)>=0}function te(e,t){return e.getElementsByTagName&&t.some(function(n){return e.getElementsByTagName(n).length})}var ve=[[/\\/g,"\\\\"],[/\*/g,"\\*"],[/^-/g,"\\-"],[/^\+ /g,"\\+ "],[/^(=+)/g,"\\$1"],[/^(#{1,6}) /g,"\\$1 "],[/`/g,"\\`"],[/^~~~/g,"\\~~~"],[/\[/g,"\\["],[/\]/g,"\\]"],[/^>/g,"\\>"],[/_/g,"\\_"],[/^(\d+)\. /g,"$1\\. "]];function ne(e){return ve.reduce(function(t,n){return t.replace(n[0],n[1])},e)}var f={};f.paragraph={filter:"p",replacement:function(e){return`

`+e+`

`}};f.lineBreak={filter:"br",replacement:function(e,t,n){return n.br+`
`}};f.heading={filter:["h1","h2","h3","h4","h5","h6"],replacement:function(e,t,n){var r=Number(t.nodeName.charAt(1));if(n.headingStyle==="setext"&&r<3){var a=R(r===1?"=":"-",e.length);return`

`+e+`
`+a+`

`}else return`

`+R("#",r)+" "+e+`

`}};f.blockquote={filter:"blockquote",replacement:function(e){return e=K(e).replace(/^/gm,"> "),`

`+e+`

`}};f.list={filter:["ul","ol"],replacement:function(e,t){var n=t.parentNode;return n.nodeName==="LI"&&n.lastElementChild===t?`
`+e:`

`+e+`

`}};f.listItem={filter:"li",replacement:function(e,t,n){var r=n.bulletListMarker+"   ",a=t.parentNode;if(a.nodeName==="OL"){var i=a.getAttribute("start"),l=Array.prototype.indexOf.call(a.children,t);r=(i?Number(i)+l:l+1)+".  "}var s=/\n$/.test(e);return e=K(e)+(s?`
`:""),e=e.replace(/\n/gm,`
`+" ".repeat(r.length)),r+e+(t.nextSibling?`
`:"")}};f.indentedCodeBlock={filter:function(e,t){return t.codeBlockStyle==="indented"&&e.nodeName==="PRE"&&e.firstChild&&e.firstChild.nodeName==="CODE"},replacement:function(e,t,n){return`

    `+t.firstChild.textContent.replace(/\n/g,`
    `)+`

`}};f.fencedCodeBlock={filter:function(e,t){return t.codeBlockStyle==="fenced"&&e.nodeName==="PRE"&&e.firstChild&&e.firstChild.nodeName==="CODE"},replacement:function(e,t,n){for(var r=t.firstChild.getAttribute("class")||"",a=(r.match(/language-(\S+)/)||[null,""])[1],i=t.firstChild.textContent,l=n.fence.charAt(0),s=3,o=new RegExp("^"+l+"{3,}","gm"),c;c=o.exec(i);)c[0].length>=s&&(s=c[0].length+1);var d=R(l,s);return`

`+d+a+`
`+i.replace(/\n$/,"")+`
`+d+`

`}};f.horizontalRule={filter:"hr",replacement:function(e,t,n){return`

`+n.hr+`

`}};f.inlineLink={filter:function(e,t){return t.linkStyle==="inlined"&&e.nodeName==="A"&&e.getAttribute("href")},replacement:function(e,t){var n=I(t.getAttribute("href")),r=P(k(t.getAttribute("title"))),a=r?' "'+r+'"':"";return"["+e+"]("+n+a+")"}};f.referenceLink={filter:function(e,t){return t.linkStyle==="referenced"&&e.nodeName==="A"&&e.getAttribute("href")},replacement:function(e,t,n){var r=I(t.getAttribute("href")),a=k(t.getAttribute("title"));a&&(a=' "'+P(a)+'"');var i,l;switch(n.linkReferenceStyle){case"collapsed":i="["+e+"][]",l="["+e+"]: "+r+a;break;case"shortcut":i="["+e+"]",l="["+e+"]: "+r+a;break;default:var s=this.references.length+1;i="["+e+"]["+s+"]",l="["+s+"]: "+r+a}return this.references.push(l),i},references:[],append:function(e){var t="";return this.references.length&&(t=`

`+this.references.join(`
`)+`

`,this.references=[]),t}};f.emphasis={filter:["em","i"],replacement:function(e,t,n){return e.trim()?n.emDelimiter+e+n.emDelimiter:""}};f.strong={filter:["strong","b"],replacement:function(e,t,n){return e.trim()?n.strongDelimiter+e+n.strongDelimiter:""}};f.code={filter:function(e){var t=e.previousSibling||e.nextSibling,n=e.parentNode.nodeName==="PRE"&&!t;return e.nodeName==="CODE"&&!n},replacement:function(e){if(!e)return"";e=e.replace(/\r?\n|\r/g," ");for(var t=/^`|^ .*?[^ ].* $|`$/.test(e)?" ":"",n="`",r=e.match(/`+/gm)||[];r.indexOf(n)!==-1;)n=n+"`";return n+t+e+t+n}};f.image={filter:"img",replacement:function(e,t){var n=ne(k(t.getAttribute("alt"))),r=I(t.getAttribute("src")||""),a=k(t.getAttribute("title")),i=a?' "'+P(a)+'"':"";return r?"!["+n+"]("+r+i+")":""}};function k(e){return e?e.replace(/(\n+\s*)+/g,`
`):""}function I(e){var t=e.replace(/([<>()])/g,"\\$1");return t.indexOf(" ")>=0?"<"+t+">":t}function P(e){return e.replace(/"/g,'\\"')}function re(e){this.options=e,this._keep=[],this._remove=[],this.blankRule={replacement:e.blankReplacement},this.keepReplacement=e.keepReplacement,this.defaultRule={replacement:e.defaultReplacement},this.array=[];for(var t in e.rules)this.array.push(e.rules[t])}re.prototype={add:function(e,t){this.array.unshift(t)},keep:function(e){this._keep.unshift({filter:e,replacement:this.keepReplacement})},remove:function(e){this._remove.unshift({filter:e,replacement:function(){return""}})},forNode:function(e){if(e.isBlank)return this.blankRule;var t;return(t=T(this.array,e,this.options))||(t=T(this._keep,e,this.options))||(t=T(this._remove,e,this.options))?t:this.defaultRule},forEach:function(e){for(var t=0;t<this.array.length;t++)e(this.array[t],t)}};function T(e,t,n){for(var r=0;r<e.length;r++){var a=e[r];if(we(a,t,n))return a}}function we(e,t,n){var r=e.filter;if(typeof r=="string"){if(r===t.nodeName.toLowerCase())return!0}else if(Array.isArray(r)){if(r.indexOf(t.nodeName.toLowerCase())>-1)return!0}else if(typeof r=="function"){if(r.call(e,t,n))return!0}else throw new TypeError("`filter` needs to be a string, array, or function")}function ke(e){var t=e.element,n=e.isBlock,r=e.isVoid,a=e.isPre||function(v){return v.nodeName==="PRE"};if(!(!t.firstChild||a(t))){for(var i=null,l=!1,s=null,o=J(s,t,a);o!==t;){if(o.nodeType===3||o.nodeType===4){var c=o.data.replace(/[ \r\n\t]+/g," ");if((!i||/ $/.test(i.data))&&!l&&c[0]===" "&&(c=c.substr(1)),!c){o=N(o);continue}o.data=c,i=o}else if(o.nodeType===1)n(o)||o.nodeName==="BR"?(i&&(i.data=i.data.replace(/ $/,"")),i=null,l=!1):r(o)||a(o)?(i=null,l=!0):i&&(l=!1);else{o=N(o);continue}var d=J(s,o,a);s=o,o=d}i&&(i.data=i.data.replace(/ $/,""),i.data||N(i))}}function N(e){var t=e.nextSibling||e.parentNode;return e.parentNode.removeChild(e),t}function J(e,t,n){return e&&e.parentNode===t||n(t)?t.nextSibling||t.parentNode:t.firstChild||t.nextSibling||t.parentNode}var H=typeof window<"u"?window:{};function Ee(){var e=H.DOMParser,t=!1;try{new e().parseFromString("","text/html")&&(t=!0)}catch{}return t}function Me(){var e=function(){};return Ce()?e.prototype.parseFromString=function(t){var n=new window.ActiveXObject("htmlfile");return n.designMode="on",n.open(),n.write(t),n.close(),n}:e.prototype.parseFromString=function(t){var n=document.implementation.createHTMLDocument("");return n.open(),n.write(t),n.close(),n},e}function Ce(){var e=!1;try{document.implementation.createHTMLDocument("").open()}catch{H.ActiveXObject&&(e=!0)}return e}var Te=Ee()?H.DOMParser:Me();function Ne(e,t){var n;if(typeof e=="string"){var r=Ae().parseFromString('<x-turndown id="turndown-root">'+e+"</x-turndown>","text/html");n=r.getElementById("turndown-root")}else n=e.cloneNode(!0);return ke({element:n,isBlock:_,isVoid:Z,isPre:t.preformattedCode?Se:null}),n}var A;function Ae(){return A=A||new Te,A}function Se(e){return e.nodeName==="PRE"||e.nodeName==="CODE"}function Le(e,t){return e.isBlock=_(e),e.isCode=e.nodeName==="CODE"||e.parentNode.isCode,e.isBlank=Re(e),e.flankingWhitespace=Oe(e,t),e}function Re(e){return!Z(e)&&!xe(e)&&/^\s*$/i.test(e.textContent)&&!ye(e)&&!be(e)}function Oe(e,t){if(e.isBlock||t.preformattedCode&&e.isCode)return{leading:"",trailing:""};var n=De(e.textContent);return n.leadingAscii&&q("left",e,t)&&(n.leading=n.leadingNonAscii),n.trailingAscii&&q("right",e,t)&&(n.trailing=n.trailingNonAscii),{leading:n.leading,trailing:n.trailing}}function De(e){var t=e.match(/^(([ \t\r\n]*)(\s*))(?:(?=\S)[\s\S]*\S)?((\s*?)([ \t\r\n]*))$/);return{leading:t[1],leadingAscii:t[2],leadingNonAscii:t[3],trailing:t[4],trailingNonAscii:t[5],trailingAscii:t[6]}}function q(e,t,n){var r,a,i;return e==="left"?(r=t.previousSibling,a=/ $/):(r=t.nextSibling,a=/^ /),r&&(r.nodeType===3?i=a.test(r.nodeValue):n.preformattedCode&&r.nodeName==="CODE"?i=!1:r.nodeType===1&&!_(r)&&(i=a.test(r.textContent))),i}var Be=Array.prototype.reduce;function E(e){if(!(this instanceof E))return new E(e);var t={rules:f,headingStyle:"setext",hr:"* * *",bulletListMarker:"*",codeBlockStyle:"indented",fence:"```",emDelimiter:"_",strongDelimiter:"**",linkStyle:"inlined",linkReferenceStyle:"full",br:"  ",preformattedCode:!1,blankReplacement:function(n,r){return r.isBlock?`

`:""},keepReplacement:function(n,r){return r.isBlock?`

`+r.outerHTML+`

`:r.outerHTML},defaultReplacement:function(n,r){return r.isBlock?`

`+n+`

`:n}};this.options=he({},t,e),this.rules=new re(this.options)}E.prototype={turndown:function(e){if(!Ie(e))throw new TypeError(e+" is not a string, or an element/document/fragment node.");if(e==="")return"";var t=ae.call(this,new Ne(e,this.options));return _e.call(this,t)},use:function(e){if(Array.isArray(e))for(var t=0;t<e.length;t++)this.use(e[t]);else if(typeof e=="function")e(this);else throw new TypeError("plugin must be a Function or an Array of Functions");return this},addRule:function(e,t){return this.rules.add(e,t),this},keep:function(e){return this.rules.keep(e),this},remove:function(e){return this.rules.remove(e),this},escape:function(e){return ne(e)}};function ae(e){var t=this;return Be.call(e.childNodes,function(n,r){r=new Le(r,t.options);var a="";return r.nodeType===3?a=r.isCode?r.nodeValue:t.escape(r.nodeValue):r.nodeType===1&&(a=$e.call(t,r)),ie(n,a)},"")}function _e(e){var t=this;return this.rules.forEach(function(n){typeof n.append=="function"&&(e=ie(e,n.append(t.options)))}),e.replace(/^[\t\r\n]+/,"").replace(/[\t\r\n\s]+$/,"")}function $e(e){var t=this.rules.forNode(e),n=ae.call(this,e),r=e.flankingWhitespace;return(r.leading||r.trailing)&&(n=n.trim()),r.leading+t.replacement(n,e,this.options)+r.trailing}function ie(e,t){var n=z(e),r=G(t),a=Math.max(e.length-n.length,t.length-r.length),i=`

`.substring(0,a);return n+i+r}function Ie(e){return e!=null&&(typeof e=="string"||e.nodeType&&(e.nodeType===1||e.nodeType===9||e.nodeType===11))}var V=/highlight-(?:text|source)-([a-z0-9]+)/;function Pe(e){e.addRule("highlightedCodeBlock",{filter:function(t){var n=t.firstChild;return t.nodeName==="DIV"&&V.test(t.className)&&n&&n.nodeName==="PRE"},replacement:function(t,n,r){var a=n.className||"",i=(a.match(V)||[null,""])[1];return`

`+r.fence+i+`
`+n.firstChild.textContent+`
`+r.fence+`

`}})}function He(e){e.addRule("strikethrough",{filter:["del","s","strike"],replacement:function(t){return"~"+t+"~"}})}var We=Array.prototype.indexOf,Fe=Array.prototype.every,x={};x.tableCell={filter:["th","td"],replacement:function(e,t){return oe(e,t)}};x.tableRow={filter:"tr",replacement:function(e,t){var n="",r={left:":--",right:"--:",center:":-:"};if(W(t))for(var a=0;a<t.childNodes.length;a++){var i="---",l=(t.childNodes[a].getAttribute("align")||"").toLowerCase();l&&(i=r[l]||i),n+=oe(i,t.childNodes[a])}return`
`+e+(n?`
`+n:"")}};x.table={filter:function(e){return e.nodeName==="TABLE"&&W(e.rows[0])},replacement:function(e){return e=e.replace(`

`,`
`),`

`+e+`

`}};x.tableSection={filter:["thead","tbody","tfoot"],replacement:function(e){return e}};function W(e){var t=e.parentNode;return t.nodeName==="THEAD"||t.firstChild===e&&(t.nodeName==="TABLE"||je(t))&&Fe.call(e.childNodes,function(n){return n.nodeName==="TH"})}function je(e){var t=e.previousSibling;return e.nodeName==="TBODY"&&(!t||t.nodeName==="THEAD"&&/^\s*$/i.test(t.textContent))}function oe(e,t){var n=We.call(t.parentNode.childNodes,t),r=" ";return n===0&&(r="| "),r+e+" |"}function Ue(e){e.keep(function(n){return n.nodeName==="TABLE"&&!W(n.rows[0])});for(var t in x)e.addRule(t,x[t])}function Je(e){e.addRule("taskListItems",{filter:function(t){return t.type==="checkbox"&&t.parentNode.nodeName==="LI"},replacement:function(t,n){return(n.checked?"[x]":"[ ]")+" "}})}function qe(e){e.use([Pe,He,Ue,Je])}const Ve=[[/α/g,"\\alpha"],[/β/g,"\\beta"],[/γ/g,"\\gamma"],[/δ/g,"\\delta"],[/ε/g,"\\varepsilon"],[/θ/g,"\\theta"],[/λ/g,"\\lambda"],[/μ/g,"\\mu"],[/π/g,"\\pi"],[/σ/g,"\\sigma"],[/φ/g,"\\varphi"],[/ω/g,"\\omega"],[/∞/g,"\\infty"],[/∑/g,"\\sum"],[/∫/g,"\\int"],[/√/g,"\\sqrt"],[/±/g,"\\pm"],[/×/g,"\\times"],[/÷/g,"\\div"],[/≤/g,"\\leq"],[/≥/g,"\\geq"],[/≠/g,"\\neq"],[/≈/g,"\\approx"],[/²/g,"^2"],[/³/g,"^3"]];function Xe(e){if(!e)return!1;if(e.matches("math, mjx-container, [data-math], [data-latex], [data-tex]")||e.matches(".katex, .katex-display, .MathJax, .MathJax_Display, .MathJax_CHTML, .MathJax_MathML, .mjx-chtml, .MJXc-display"))return!0;const t=nt(e);return/\b(math-|equation|formula)\b/.test(t)}function S(e){if(!(e instanceof Element))return null;const t=e.closest(".katex, .katex-display, mjx-container, .MathJax_Display, .MJXc-display, .MathJax, .mjx-chtml, .MathJax_CHTML, .MathJax_MathML, [data-math], math, [data-latex], [data-tex]");if(t)return t;let n=e,r=null;for(let a=0;n&&a<20;a+=1)Xe(n)&&(r=n),n=n.parentElement;return r}function O(e){var d;const t=Ze(e);if(t)return t;const n=M(e,["data-math"]);if(n)return{latex:n,mode:g(e),source:"data-math"};const r=ze(e);if(r)return r;const a=Ke(e);if(a)return a;const i=Qe(e);if(i)return i;const l=M(e,["data-latex","data-tex","aria-label","title"]);if(l)return{latex:l,mode:g(e),source:"attribute"};const s=((d=e.textContent)==null?void 0:d.trim())??"";if(!s)return null;const o=tt(s);if(o)return{latex:o.latex,mode:o.mode,source:"delimited-text"};const c=Ge(s);return c!==s?{latex:c,mode:g(e),source:"unicode-fallback"}:null}function Ye(e){return e==="display"?"$$":"$"}function le(e,t){const n=Ye(t);return`${n}${e.trim()}${n}`}function Ge(e){let t=e;for(const[n,r]of Ve)t=t.replace(n,r);return t=t.replace(/(\b\w+)\^(\w+)/g,"$1^{$2}"),t=t.replace(/\be\s*i\s*(\\pi|\\theta|[a-zA-Z]+)/g,"e^{i$1}"),t}function g(e){if(e.matches(".katex-display, .MathJax_Display, .MJXc-display")||e.tagName.toLowerCase()==="mjx-container"&&e.hasAttribute("display")||e.matches("img.mwe-math-fallback-image-display"))return"display";const t=e.parentElement;if(t!=null&&t.classList.contains("katex-display"))return"display";if(e.hasAttribute("data-math"))return e.tagName.toLowerCase()==="div"?"display":"inline";const n=rt(e);return n&&n.display==="block"?"display":"inline"}function ze(e){var a;const t=e.closest(".katex")??(e.matches(".katex-display")?e.querySelector(".katex"):null);if(!t)return null;const n=t.querySelector('annotation[encoding="application/x-tex"], annotation[encoding="application/x-latex"], annotation[encoding="application/tex"]'),r=((a=n==null?void 0:n.textContent)==null?void 0:a.trim())||M(t,["data-latex","data-tex","aria-label","title"]);return r?{latex:r,mode:g(t),source:"katex"}:null}function Ke(e){var l,s,o;const t=e.closest("mjx-container, .MathJax_Display, .MJXc-display, .MathJax, .mjx-chtml, .MathJax_CHTML, .MathJax_MathML");if(!t)return null;const n=t.querySelector('script[type*="math/tex"]');if((l=n==null?void 0:n.textContent)!=null&&l.trim())return{latex:n.textContent.trim(),mode:g(t),source:"mathjax-script-child"};const r=et(t);if((s=r==null?void 0:r.textContent)!=null&&s.trim())return{latex:r.textContent.trim(),mode:r.type.includes("mode=display")?"display":g(t),source:"mathjax-script-sibling"};const a=t.querySelector("mjx-assistive-mml annotation");if((o=a==null?void 0:a.textContent)!=null&&o.trim())return{latex:a.textContent.trim(),mode:g(t),source:"mathjax-assistive"};const i=M(t,["data-latex","data-tex","aria-label","title"]);return i?{latex:i,mode:g(t),source:"mathjax-attribute"}:null}function Qe(e){var r;const t=e.closest("math")??e.querySelector("math");if(!t)return null;const n=t.querySelector('annotation[encoding="application/x-tex"], annotation[encoding="application/x-latex"], annotation[encoding="application/tex"]');return(r=n==null?void 0:n.textContent)!=null&&r.trim()?{latex:n.textContent.trim(),mode:g(t),source:"mathml-annotation"}:null}function Ze(e){var r;if(!(e instanceof HTMLImageElement)||!e.matches("img.mwe-math, img.mwe-math-fallback-image-inline, img.mwe-math-fallback-image-display"))return null;const t=(r=e.getAttribute("alt"))==null?void 0:r.trim();if(!t)return null;const n=t.match(/^\{\\displaystyle\s*([\s\S]*?)\}$/);return{latex:((n==null?void 0:n[1])??t).trim(),mode:g(e),source:"wikipedia-alt"}}function M(e,t){var n;for(const r of t){const a=(n=e.getAttribute(r))==null?void 0:n.trim();if(a&&(r==="data-math"||a.includes("\\")||/[$^_{}]/.test(a)))return a}return null}function et(e){let t=e;for(let n=0;t&&n<8;n+=1)if(t=t.nextElementSibling,t instanceof HTMLScriptElement&&t.type.includes("math/tex"))return t;t=e;for(let n=0;t&&n<4;n+=1)if(t=t.previousElementSibling,t instanceof HTMLScriptElement&&t.type.includes("math/tex"))return t;return null}function tt(e){return e.startsWith("$$")&&e.endsWith("$$")&&e.length>4?{latex:e.slice(2,-2).trim(),mode:"display"}:e.startsWith("\\[")&&e.endsWith("\\]")&&e.length>4?{latex:e.slice(2,-2).trim(),mode:"display"}:e.startsWith("$")&&e.endsWith("$")&&e.length>2?{latex:e.slice(1,-1).trim(),mode:"inline"}:e.startsWith("\\(")&&e.endsWith("\\)")&&e.length>4?{latex:e.slice(2,-2).trim(),mode:"inline"}:null}function nt(e){const t=e.className;return typeof t=="string"?t:t&&typeof t.baseVal=="string"?t.baseVal:""}function rt(e){try{return window.getComputedStyle(e)}catch{return null}}function at(){const e=window.getSelection();if(!e||e.rangeCount===0||e.toString().trim()==="")return"";const t=document.createElement("div");for(let n=0;n<e.rangeCount;n+=1)t.append(e.getRangeAt(n).cloneContents());return t.innerHTML}function it(){const e=at();return e?st(e):""}function ot(){const e=document.body;if(!e)return"";const t=mt(),n=C(e);return[t,n].filter(Boolean).join(`

---

`)}function C(e){const t=e.cloneNode(!0);return t instanceof Element?se(t):""}function lt(e){return e.map(t=>C(t)).map(t=>t.trim()).filter(Boolean).join(`

---

`)}function st(e){const t=document.createElement("div");return t.innerHTML=e,se(t)}function se(e){ct(e),ft(e),dt(e);const t=new E({headingStyle:"atx",codeBlockStyle:"fenced",bulletListMarker:"-",emDelimiter:"*"});t.use(qe),t.addRule("latexMarker",{filter:r=>r.nodeType===Node.ELEMENT_NODE&&r.classList.contains("copy-web-to-ai-latex-marker"),replacement:(r,a)=>{const i=a,l=i.textContent??"";return i.getAttribute("data-display-mode")==="display"?`

${l}

`:l}}),t.addRule("preserveLineBreaks",{filter:"br",replacement:()=>`
`}),t.addRule("disabledTaskCheckbox",{filter:r=>r.nodeName==="INPUT"&&r.type==="checkbox",replacement:(r,a)=>a.checked?"[x] ":"[ ] "});const n=t.turndown(e.innerHTML);return ht(n)}function ct(e){const t=ut(e);for(const n of t){if(!e.contains(n))continue;const r=O(n);if(!r)continue;const a=document.createElement(r.mode==="display"?"div":"span");a.className="copy-web-to-ai-latex-marker",a.dataset.displayMode=r.mode,a.textContent=le(r.latex,r.mode),n.replaceWith(a)}}function ut(e){const t=[".katex-display",".katex","mjx-container",".MathJax_Display",".MJXc-display",".MathJax",".mjx-chtml",".MathJax_CHTML",".MathJax_MathML","[data-math]","math","[data-latex]","[data-tex]","img.mwe-math","img.mwe-math-fallback-image-inline","img.mwe-math-fallback-image-display"].join(","),n=Array.from(e.querySelectorAll(t));return n.filter(r=>!n.some(a=>a!==r&&a.contains(r)))}function ft(e){e.querySelectorAll(["script","style","noscript","template","iframe","object","embed","canvas","[hidden]","[inert]","[aria-hidden='true']","dialog:not([open])","#copy-web-to-ai-ui-root","svg[aria-hidden='true']","[aria-hidden='true'] .katex-html",".katex-html",".katex-mathml","mjx-assistive-mml","[data-testid='copy-turn-action-button']","[data-testid='good-response-turn-action-button']","[data-testid='bad-response-turn-action-button']","button","[role='button'][aria-label*='Copy']","[role='button'][aria-label*='复制']"].join(",")).forEach(t=>t.remove())}function dt(e){e.querySelectorAll("a[href]").forEach(t=>{try{t.setAttribute("href",t.href)}catch{}}),e.querySelectorAll("img[src]").forEach(t=>{try{t.setAttribute("src",t.src)}catch{}})}function mt(){const e=[],t=document.title.trim();t&&e.push(`# ${pt(t)}`);const n=window.location.href;return n&&!n.startsWith("about:")&&e.push(`Source: ${n}`),e.join(`

`)}function pt(e){return e.replace(/\s+/g," ").replace(/^#+\s*/,"")}function ht(e){return e.replace(/\u00a0/g," ").replace(/[ \t]+\n/g,`
`).replace(/^(\s*[-*+]) {2,}/gm,"$1 ").replace(/\n{3,}/g,`

`).replace(/\n?(\$\$[\s\S]+?\$\$)\n?/g,`

$1

`).replace(/\n{3,}/g,`

`).trim()}const ce=['[data-message-author-role="assistant"]','[data-testid^="conversation-turn-"]:has([data-message-author-role="assistant"])',".agent-turn",".model-response-text",".markdown.prose",".ds-markdown","[data-response-index]"],gt=['[data-message-author-role="user"]','[data-message-author-role="assistant"]','[data-testid^="conversation-turn-"]',"article","[role='article']"],yt=["main",'[role="main"]','[data-testid="conversation-panel"]',".conversation",".chat-container"];let D=null;function xt(){document.addEventListener("pointermove",e=>{e.target instanceof Element&&(D=e.target)},{capture:!0,passive:!0})}function bt(){const e=kt();return e?C(e):""}function vt(){const e=Et();if(e.length>0)return lt(e);const t=F();return t?C(t):""}function wt(){return ot()}function kt(){if(D){const r=X(D);if(r&&b(r))return r}const e=window.getSelection(),t=e==null?void 0:e.anchorNode,n=t instanceof Element?t:(t==null?void 0:t.parentElement)??null;if(n){const r=X(n);if(r&&b(r))return r}return ue().at(-1)??null}function ue(){const e=F()??document.body,n=de(ce.flatMap(r=>fe(e,r))).filter(r=>{var a;return((a=r.textContent)==null?void 0:a.trim())||r.querySelector("img, canvas, math, .katex, mjx-container")}).filter(b);return n.length>0?n:Array.from(e.querySelectorAll("article, [role='article']")).filter(b)}function Et(){const e=F()??document.body,n=de(gt.flatMap(r=>fe(e,r))).filter(r=>{var a;return((a=r.textContent)==null?void 0:a.trim())||r.querySelector("img, canvas, math, .katex, mjx-container")}).filter(b);return n.length>0?n:ue()}function X(e){for(const t of ce){const n=Mt(e,t);if(n)return n}return null}function F(){for(const e of yt){const t=document.querySelector(e);if(t&&b(t))return t}return document.body}function fe(e,t){try{return Array.from(e.querySelectorAll(t))}catch{return[]}}function Mt(e,t){try{return e.closest(t)}catch{return null}}function de(e){const t=[];for(const n of e)t.some(r=>r===n||r.contains(n))||t.push(n);return t.sort(Ct)}function Ct(e,t){if(e===t)return 0;const n=e.compareDocumentPosition(t);return n&Node.DOCUMENT_POSITION_PRECEDING?1:n&Node.DOCUMENT_POSITION_FOLLOWING?-1:0}function b(e){const t=e.getBoundingClientRect();if(t.width<=0||t.height<=0||t.bottom<0||t.top>window.innerHeight)return!1;const n=window.getComputedStyle(e);return n.visibility!=="hidden"&&n.display!=="none"&&n.opacity!=="0"}const m="copy-web-to-ai-ui-root";let L=null;async function j(e){if(!e.trim())throw new Error("没有可复制的内容");try{await navigator.clipboard.writeText(e);return}catch{const t=document.createElement("textarea");t.value=e,t.style.position="fixed",t.style.left="-9999px",t.style.top="0",t.setAttribute("readonly","true"),document.body.append(t),t.select();const n=document.execCommand("copy");if(t.remove(),!n)throw new Error("剪贴板写入失败")}}function p(e,t="info"){const n=U();let r=n.querySelector(".copy-web-to-ai-toast");r||(r=document.createElement("div"),r.className="copy-web-to-ai-toast",n.append(r)),r.textContent=e,r.dataset.tone=t,r.dataset.visible="true",L&&window.clearTimeout(L),L=window.setTimeout(()=>{r==null||r.removeAttribute("data-visible")},2200)}function U(){let e=document.getElementById(m);if(e)return e;e=document.createElement("div"),e.id=m,document.documentElement.append(e);const t=document.createElement("style");return t.textContent=`
    #${m} {
      all: initial;
      color-scheme: light dark;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      position: fixed;
      inset: 0;
      pointer-events: none;
      z-index: 2147483647;
    }

    #${m} .copy-web-to-ai-toast {
      position: fixed;
      left: 50%;
      bottom: 28px;
      transform: translateX(-50%) translateY(12px);
      max-width: min(420px, calc(100vw - 32px));
      padding: 10px 14px;
      border-radius: 8px;
      background: rgba(28, 28, 32, 0.94);
      color: #fff;
      box-shadow: 0 8px 28px rgba(0, 0, 0, 0.24);
      font: 13px/1.4 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      opacity: 0;
      pointer-events: none;
      transition: opacity 160ms ease, transform 160ms ease;
      white-space: normal;
    }

    #${m} .copy-web-to-ai-toast[data-visible="true"] {
      opacity: 1;
      transform: translateX(-50%) translateY(0);
    }

    #${m} .copy-web-to-ai-toast[data-tone="ok"] {
      background: rgba(28, 116, 64, 0.96);
    }

    #${m} .copy-web-to-ai-toast[data-tone="error"] {
      background: rgba(178, 45, 45, 0.96);
    }

    #${m} .copy-web-to-ai-formula-button {
      position: fixed;
      min-width: 48px;
      height: 28px;
      padding: 0 10px;
      border: 1px solid rgba(255, 255, 255, 0.24);
      border-radius: 8px;
      background: rgba(25, 27, 32, 0.94);
      color: #fff;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.22);
      font: 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      cursor: pointer;
      pointer-events: auto;
    }

    #${m} .copy-web-to-ai-ocr-layer {
      position: fixed;
      inset: 0;
      cursor: crosshair;
      background: rgba(0, 0, 0, 0.16);
      pointer-events: auto;
    }

    #${m} .copy-web-to-ai-ocr-box {
      position: fixed;
      border: 2px solid #ffffff;
      background: rgba(59, 130, 246, 0.18);
      box-shadow: 0 0 0 9999px rgba(0, 0, 0, 0.20);
    }

    #${m} .copy-web-to-ai-ocr-hint {
      position: fixed;
      top: 16px;
      left: 50%;
      transform: translateX(-50%);
      padding: 8px 12px;
      border-radius: 8px;
      background: rgba(25, 27, 32, 0.94);
      color: #fff;
      font: 13px/1.35 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.22);
    }
  `,e.append(t),e}function Tt(){return new Promise(e=>{const t=U(),n=document.createElement("div"),r=document.createElement("div"),a=document.createElement("div");n.className="copy-web-to-ai-ocr-layer",r.className="copy-web-to-ai-ocr-box",a.className="copy-web-to-ai-ocr-hint",a.textContent="拖拽框选要 OCR 的可见区域，按 Esc 取消",n.append(r,a),t.append(n);let i=0,l=0,s=!1;const o=()=>{n.remove(),window.removeEventListener("keydown",d,!0),window.removeEventListener("blur",c,!0)},c=()=>{o(),e(null)},d=u=>{u.key==="Escape"&&(u.preventDefault(),c())},v=u=>{const h=Y(i,l,u.clientX,u.clientY);r.style.left=`${h.x}px`,r.style.top=`${h.y}px`,r.style.width=`${h.width}px`,r.style.height=`${h.height}px`};n.addEventListener("pointerdown",u=>{u.preventDefault(),s=!0,i=u.clientX,l=u.clientY,n.setPointerCapture(u.pointerId),v(u)}),n.addEventListener("pointermove",u=>{s&&(u.preventDefault(),v(u))}),n.addEventListener("pointerup",u=>{if(!s)return;u.preventDefault(),s=!1;const h=Y(i,l,u.clientX,u.clientY);if(o(),h.width<8||h.height<8){p("框选区域太小","error"),e(null);return}e({...h,viewportWidth:window.innerWidth,viewportHeight:window.innerHeight})}),window.addEventListener("keydown",d,!0),window.addEventListener("blur",c,!0)})}function Y(e,t,n,r){const a=Math.max(0,Math.min(e,n)),i=Math.max(0,Math.min(t,r)),l=Math.min(window.innerWidth,Math.max(e,n)),s=Math.min(window.innerHeight,Math.max(t,r));return{x:a,y:i,width:l-a,height:s-i}}const B="copy-web-to-ai-unlock-style";let y=!1;const me=["copy","cut","selectstart","selectionchange","contextmenu","mousedown","mouseup","dragstart"];function Nt(){return y=!y,y?St():Lt(),y}function At(){return y}function St(){Rt();for(const e of me)document.addEventListener(e,pe,!0);p("已临时解锁当前页面复制","ok")}function Lt(){var e;(e=document.getElementById(B))==null||e.remove();for(const t of me)document.removeEventListener(t,pe,!0);p("已关闭解锁复制","info")}function Rt(){if(document.getElementById(B))return;const e=document.createElement("style");e.id=B,e.textContent=`
    html, body, body * {
      user-select: text !important;
      -webkit-user-select: text !important;
      -moz-user-select: text !important;
      -ms-user-select: text !important;
    }
  `,document.documentElement.append(e)}function pe(e){var n,r;if(!y)return;const t=e.target;if(!(t instanceof Element&&t.closest("#copy-web-to-ai-ui-root"))&&(e.stopImmediatePropagation(),e.type==="copy")){const a=((n=window.getSelection())==null?void 0:n.toString())??"";if(!a.trim())return;const i=e;(r=i.clipboardData)==null||r.setData("text/plain",a),i.clipboardData&&e.preventDefault()}}window.__copyWebToAiLoaded||(window.__copyWebToAiLoaded=!0,xt(),_t(),Ot());function Ot(){chrome.runtime.onMessage.addListener((e,t,n)=>(Dt(e).then(r=>n(r)).catch(r=>{const a=r instanceof Error?r.message:String(r);p(a,"error"),n({ok:!1,error:a})}),!0))}async function Dt(e){switch(e.type){case"PING_COPY_WEB_TO_AI":return{ok:!0};case"COPY_SELECTION_MARKDOWN":return w(it(),"已复制选区 Markdown");case"COPY_ACTIVE_ANSWER":return w(bt(),"已复制当前回答");case"COPY_VISIBLE_CHAT":return w(vt(),"已复制可见会话");case"COPY_FULL_PAGE_MARKDOWN":return w(wt(),"已复制整页 Markdown");case"TOGGLE_UNLOCK_COPY":return{ok:!0,enabled:Nt()};case"START_REGION_OCR":return Bt();default:return{ok:!1,error:"未知指令"}}}async function w(e,t){if(!e.trim())throw new Error("没有找到可复制内容");return await j(e),p(t,"ok"),{ok:!0,length:e.length}}async function Bt(){p("准备框选 OCR 区域","info");const e=await Tt();if(!e)return{ok:!1,cancelled:!0};p("正在上传到 MinerU OCR...","info");const t=await chrome.runtime.sendMessage({type:"RUN_MINERU_OCR",rect:e});if(!t.ok)throw new Error(t.error);return await j(t.markdown),p("OCR 结果已复制","ok"),{ok:!0,length:t.markdown.length}}async function _t(){if(!await $t())return;const t=U(),n=document.createElement("button");n.type="button",n.className="copy-web-to-ai-formula-button",n.textContent="复制",n.title="复制 LaTeX",n.style.display="none",t.append(n);let r=null,a=null;const i=()=>{n.style.display="none",r=null},l=()=>{a&&window.clearTimeout(a),a=window.setTimeout(()=>{n.matches(":hover")||i()},120)};document.addEventListener("mouseover",s=>{if(At())return;const o=S(s.target);if(!o||o===r||!O(o))return;r=o;const d=o.getBoundingClientRect(),u=Math.min(window.innerWidth-54-8,Math.max(8,d.right+8)),h=Math.min(window.innerHeight-32,Math.max(8,d.top));n.style.left=`${u}px`,n.style.top=`${h}px`,n.style.display="block"},!0),document.addEventListener("mouseout",s=>{const o=S(s.target),c=S(s.relatedTarget);o&&o!==c&&l()},!0),n.addEventListener("mouseleave",l),n.addEventListener("click",async s=>{if(s.preventDefault(),s.stopPropagation(),!r)return;const o=O(r);if(!o){p("没有找到 LaTeX 源码","error");return}try{await j(le(o.latex,o.mode)),n.textContent="已复制",p("LaTeX 已复制","ok"),window.setTimeout(()=>{n.textContent="复制"},1e3)}catch(c){p(c instanceof Error?c.message:"复制失败","error")}})}async function $t(){try{return(await chrome.storage.local.get({enableFormulaButton:!0})).enableFormulaButton!==!1}catch{return!0}}

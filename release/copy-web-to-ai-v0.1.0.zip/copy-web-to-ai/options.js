import"./chunks/modulepreload-polyfill.js";const d=document.getElementById("app");if(!d)throw new Error("Missing options root");d.innerHTML=`
  <section class="shell">
    <header>
      <h1>Copy Web to AI 设置</h1>
      <p>Token 只保存在本机浏览器的 local storage。</p>
    </header>

    <form id="settings-form">
      <label>
        <span>MinerU Token</span>
        <input id="mineru-token" name="mineruToken" type="password" autocomplete="off" spellcheck="false" />
      </label>

      <label>
        <span>MinerU 用户标识（可选）</span>
        <input id="mineru-user-id" name="mineruUserId" type="text" autocomplete="off" spellcheck="false" placeholder="留空时自动从 JWT uuid 读取" />
      </label>

      <div class="row">
        <label>
          <span>OCR 语言</span>
          <input id="ocr-language" name="ocrLanguage" type="text" value="ch" />
        </label>

        <label>
          <span>OCR 超时秒数</span>
          <input id="ocr-timeout" name="ocrTimeoutSeconds" type="number" min="30" max="600" step="10" />
        </label>
      </div>

      <label class="check">
        <input id="enable-formula-button" name="enableFormulaButton" type="checkbox" />
        <span>启用公式悬浮复制按钮</span>
      </label>

      <label class="check">
        <input id="allow-all-sites" name="allowAllSites" type="checkbox" />
        <span>允许快捷键和右键菜单在所有网站按需注入</span>
      </label>

      <div class="actions">
        <button type="submit">保存设置</button>
      </div>
    </form>

    <p id="status" role="status"></p>
  </section>
`;g();m();var c;(c=document.getElementById("settings-form"))==null||c.addEventListener("submit",async e=>{e.preventDefault(),await p()});var u;(u=document.getElementById("allow-all-sites"))==null||u.addEventListener("change",async e=>{const t=e.currentTarget;if(!i()){t.checked=!1,l("请在已加载的浏览器扩展中授权","error");return}t.checked?await chrome.permissions.request({origins:["<all_urls>"]})||(t.checked=!1,l("浏览器未授予所有网站权限","error")):await chrome.permissions.remove({origins:["<all_urls>"]})});async function m(){if(!i()){const t={mineruToken:"",mineruUserId:"",ocrLanguage:"ch",ocrTimeoutSeconds:180,allowAllSites:!1,enableFormulaButton:!0};n("mineru-token",t.mineruToken),n("mineru-user-id",t.mineruUserId),n("ocr-language",t.ocrLanguage),n("ocr-timeout",String(t.ocrTimeoutSeconds)),r("allow-all-sites",t.allowAllSites),r("enable-formula-button",t.enableFormulaButton);return}const e=await chrome.storage.local.get({mineruToken:"",mineruUserId:"",ocrLanguage:"ch",ocrTimeoutSeconds:180,allowAllSites:!1,enableFormulaButton:!0});n("mineru-token",e.mineruToken),n("mineru-user-id",e.mineruUserId),n("ocr-language",e.ocrLanguage),n("ocr-timeout",String(e.ocrTimeoutSeconds)),r("allow-all-sites",e.allowAllSites),r("enable-formula-button",e.enableFormulaButton)}async function p(){if(!i()){l("请在已加载的浏览器扩展中保存","error");return}const e={mineruToken:a("mineru-token").trim(),mineruUserId:a("mineru-user-id").trim(),ocrLanguage:a("ocr-language").trim()||"ch",ocrTimeoutSeconds:f(Number(a("ocr-timeout"))||180,30,600),allowAllSites:s("allow-all-sites"),enableFormulaButton:s("enable-formula-button")};await chrome.storage.local.set(e),l("已保存","ok")}function a(e){const t=document.getElementById(e);return(t==null?void 0:t.value)??""}function n(e,t){const o=document.getElementById(e);o&&(o.value=t)}function s(e){const t=document.getElementById(e);return(t==null?void 0:t.checked)??!1}function r(e,t){const o=document.getElementById(e);o&&(o.checked=t)}function l(e,t){const o=document.getElementById("status");o&&(o.textContent=e,o.dataset.tone=t)}function f(e,t,o){return Math.min(o,Math.max(t,e))}function g(){const e=document.createElement("style");e.textContent=`
    :root {
      color-scheme: light dark;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      background: #f7f7f8;
      color: #1d1d20;
    }

    body {
      margin: 0;
      background: #f7f7f8;
    }

    .shell {
      width: min(680px, calc(100vw - 32px));
      margin: 36px auto;
    }

    header {
      margin-bottom: 20px;
    }

    h1 {
      margin: 0;
      font-size: 24px;
      line-height: 1.2;
      letter-spacing: 0;
    }

    p {
      margin: 6px 0 0;
      color: #62636b;
      font-size: 13px;
      line-height: 1.45;
    }

    form {
      display: grid;
      gap: 16px;
      padding: 18px;
      border: 1px solid #dedee5;
      border-radius: 8px;
      background: #fff;
    }

    label {
      display: grid;
      gap: 7px;
      color: #34343a;
      font-size: 13px;
      font-weight: 600;
    }

    input[type="text"],
    input[type="password"],
    input[type="number"] {
      width: 100%;
      box-sizing: border-box;
      min-height: 38px;
      border: 1px solid #cfd0d8;
      border-radius: 8px;
      padding: 8px 10px;
      background: #fff;
      color: #1d1d20;
      font: 14px/1.3 ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
    }

    .row {
      display: grid;
      grid-template-columns: 1fr 180px;
      gap: 12px;
    }

    .check {
      display: flex;
      align-items: center;
      gap: 10px;
      min-height: 28px;
      font-weight: 500;
    }

    .check input {
      width: 16px;
      height: 16px;
      margin: 0;
    }

    .actions {
      display: flex;
      justify-content: flex-end;
    }

    button {
      min-height: 38px;
      border: 1px solid #1f2937;
      border-radius: 8px;
      padding: 0 16px;
      background: #1f2937;
      color: #fff;
      cursor: pointer;
      font: 13px/1.2 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      font-weight: 600;
    }

    #status {
      min-height: 20px;
      margin-top: 12px;
      color: #62636b;
    }

    #status[data-tone="ok"] {
      color: #17633a;
    }

    #status[data-tone="error"] {
      color: #b42318;
    }

    @media (max-width: 560px) {
      .row {
        grid-template-columns: 1fr;
      }
    }

    @media (prefers-color-scheme: dark) {
      :root,
      body {
        background: #17181c;
        color: #f4f4f5;
      }

      form {
        border-color: #383a42;
        background: #22232a;
      }

      label {
        color: #f4f4f5;
      }

      p,
      #status {
        color: #a3a3aa;
      }

      input[type="text"],
      input[type="password"],
      input[type="number"] {
        border-color: #494b55;
        background: #17181c;
        color: #f4f4f5;
      }

      button {
        border-color: #d9dbe1;
        background: #f4f4f5;
        color: #17181c;
      }

      #status[data-tone="ok"] {
        color: #6ee7a4;
      }

      #status[data-tone="error"] {
        color: #fda29b;
      }
    }
  `,document.head.append(e)}function i(){var e;return typeof chrome<"u"&&!!((e=chrome.runtime)!=null&&e.id)}

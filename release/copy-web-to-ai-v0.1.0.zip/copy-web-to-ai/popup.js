import"./chunks/modulepreload-polyfill.js";const c=document.getElementById("app");if(!c)throw new Error("Missing popup root");c.innerHTML=`
  <section class="panel">
    <header>
      <div>
        <h1>Copy Web to AI</h1>
        <p id="host">当前标签页</p>
      </div>
      <button class="icon-button" id="open-options" title="设置" type="button">⚙</button>
    </header>

    <div class="grid">
      <button data-action="COPY_SELECTION_MARKDOWN" type="button">
        <span class="icon">S</span>
        <span>复制选区</span>
      </button>
      <button data-action="COPY_ACTIVE_ANSWER" type="button">
        <span class="icon">A</span>
        <span>复制当前回答</span>
      </button>
      <button data-action="COPY_VISIBLE_CHAT" type="button">
        <span class="icon">M</span>
        <span>复制可见会话</span>
      </button>
      <button data-action="COPY_FULL_PAGE_MARKDOWN" type="button">
        <span class="icon">P</span>
        <span>复制整页</span>
      </button>
      <button data-action="TOGGLE_UNLOCK_COPY" type="button">
        <span class="icon">U</span>
        <span>解锁复制</span>
      </button>
      <button data-action="START_REGION_OCR" class="wide" type="button">
        <span class="icon">O</span>
        <span>框选 OCR</span>
      </button>
    </div>

    <p id="status" role="status"></p>
  </section>
`;l();p();var r;(r=document.getElementById("open-options"))==null||r.addEventListener("click",()=>{if(!s()){e("扩展环境中可打开设置","info");return}chrome.runtime.openOptionsPage()});document.querySelectorAll("[data-action]").forEach(t=>{t.addEventListener("click",async()=>{const n=t.dataset.action;await d(n,t)})});async function d(t,n){e("处理中...","info"),i(!0);try{if(!s())throw new Error("请在已加载的浏览器扩展中使用");const o=await chrome.runtime.sendMessage({type:"EXECUTE_COPY_WEB_TO_AI_ACTION",action:t});if(o!=null&&o.ok)e(t==="TOGGLE_UNLOCK_COPY"?"已切换":"已发送到页面","ok");else if(o==null?void 0:o.cancelled)e("已取消","info");else throw new Error((o==null?void 0:o.error)||"操作失败")}catch(o){e(o instanceof Error?o.message:String(o),"error")}finally{i(!1),n.focus()}}async function p(){if(!s()){const a=document.getElementById("host");a&&(a.textContent="预览模式");return}const[t]=await chrome.tabs.query({active:!0,currentWindow:!0}),n=t!=null&&t.url?new URL(t.url).hostname:"当前标签页",o=document.getElementById("host");o&&(o.textContent=n)}function e(t,n){const o=document.getElementById("status");o&&(o.textContent=t,o.dataset.tone=n)}function i(t){document.querySelectorAll("button").forEach(n=>{n.disabled=t})}function l(){const t=document.createElement("style");t.textContent=`
    :root {
      color-scheme: light dark;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      background: #f7f7f8;
      color: #1d1d20;
    }

    body {
      width: 320px;
      margin: 0;
      background: #f7f7f8;
    }

    .panel {
      padding: 14px;
    }

    header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      margin-bottom: 12px;
    }

    h1 {
      margin: 0;
      font-size: 16px;
      line-height: 1.2;
      letter-spacing: 0;
    }

    p {
      margin: 0;
    }

    #host {
      margin-top: 3px;
      max-width: 236px;
      overflow: hidden;
      color: #63636b;
      font-size: 12px;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
    }

    button {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      min-height: 42px;
      border: 1px solid #d8d8df;
      border-radius: 8px;
      background: #ffffff;
      color: #202026;
      cursor: pointer;
      font: 13px/1.2 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    }

    button:hover {
      border-color: #9ca3af;
      background: #fdfdfd;
    }

    button:disabled {
      cursor: wait;
      opacity: 0.58;
    }

    .icon-button {
      width: 32px;
      min-height: 32px;
      padding: 0;
    }

    .wide {
      grid-column: 1 / -1;
    }

    .icon {
      display: inline-grid;
      place-items: center;
      width: 18px;
      height: 18px;
      border-radius: 50%;
      background: #ececf1;
      color: #34343a;
      font-size: 11px;
      font-weight: 700;
    }

    #status {
      min-height: 18px;
      margin-top: 10px;
      color: #63636b;
      font-size: 12px;
      line-height: 1.4;
    }

    #status[data-tone="ok"] {
      color: #17633a;
    }

    #status[data-tone="error"] {
      color: #b42318;
    }

    @media (prefers-color-scheme: dark) {
      :root,
      body {
        background: #17181c;
        color: #f4f4f5;
      }

      #host,
      #status {
        color: #a3a3aa;
      }

      button {
        border-color: #393a42;
        background: #22232a;
        color: #f4f4f5;
      }

      button:hover {
        border-color: #666977;
        background: #292a32;
      }

      .icon {
        background: #343640;
        color: #f4f4f5;
      }

      #status[data-tone="ok"] {
        color: #6ee7a4;
      }

      #status[data-tone="error"] {
        color: #fda29b;
      }
    }
  `,document.head.append(t)}function s(){var t;return typeof chrome<"u"&&!!((t=chrome.runtime)!=null&&t.id)}
